1. Unzip smp361_20210305_184730.zip into a directory
2. Review 00001_smp361_index.html
