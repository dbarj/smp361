1. Unzip smp361_klr8s3fx1b_feky1pod_20210305_184510.zip into a directory
2. Review 00001_smp361_klr8s3fx1b_index.html
